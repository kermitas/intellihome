Here are my old arduino works (simple REST server and codes for WiFi<->RS232 converter from usr.cn).
