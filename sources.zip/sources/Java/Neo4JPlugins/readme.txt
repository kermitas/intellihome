In this project I am going to keep Neo4J server managed and unmanaged plugins.
