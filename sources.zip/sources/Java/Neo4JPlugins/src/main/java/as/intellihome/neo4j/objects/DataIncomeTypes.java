package as.intellihome.neo4j.objects;

// ====================================================

public interface DataIncomeTypes extends NodeContainer
{
    // ================================================
    
    public void setDevicePushDataIncomeType( Device device );
    
    // ================================================
    
    public void setServerTcpIpPullDataIncomeType( Device device , String ip , int port );

    // ================================================
}

// ====================================================