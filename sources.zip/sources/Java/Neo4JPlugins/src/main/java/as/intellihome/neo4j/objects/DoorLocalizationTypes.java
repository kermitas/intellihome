package as.intellihome.neo4j.objects;

// ====================================================

public interface DoorLocalizationTypes extends NodeContainer
{
    // ================================================
    
    public void setDoorLocalizationType( Sensor sensor , Relations.DoorLocalizationType doorLocalizationType );

    // ================================================
}

// ====================================================