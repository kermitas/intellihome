package as.intellihome.neo4j.objects;

// ====================================================

public interface DevicesGroup extends NodeContainer
{
    // ================================================
    
    public void addDeviceToGroup( Device device );

    // ================================================
}

// ====================================================