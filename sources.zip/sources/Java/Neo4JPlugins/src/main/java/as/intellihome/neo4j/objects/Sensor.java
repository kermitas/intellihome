package as.intellihome.neo4j.objects;

// ====================================================

public interface Sensor extends NodeContainer
{
    // ================================================
    
    public SensorSample createSensorSample( String value );
    
    // ================================================
    
    public boolean containsSensorSample();
    
    // ================================================
    
    public SensorSample getLatestSensorSample();
    
    // ================================================
}

// ====================================================