package as.intellihome.neo4j.objects;

// ====================================================

public interface SensorsGroup extends NodeContainer
{
    // ================================================
    
    public void addSensorToGroup( Sensor sensor );

    // ================================================
}

// ====================================================