package as.intellihome.neo4j.objects;

// ====================================================

public interface InSystemLocalizationTypes extends NodeContainer
{
    // ================================================
    
    public void setInSystemLocalizationType( Device device , Relations.InSystemLocalizationType inSystemLocalizationType );
    
    // ================================================
}

// ====================================================