package as.intellihome.neo4j.objects;

// ====================================================

public interface StartupTime extends NodeContainer
{
    // ================================================
    
    public void setShutdownTime();
    
    // ================================================
}

// ====================================================