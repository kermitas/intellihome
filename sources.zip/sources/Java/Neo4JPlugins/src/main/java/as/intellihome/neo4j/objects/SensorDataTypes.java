package as.intellihome.neo4j.objects;

// ====================================================

public interface SensorDataTypes extends NodeContainer
{
    // ================================================
    
    public void setSensorDataType( Sensor sensor , Relations.SensorDataType sensorDataType );

    // ================================================
}

// ====================================================