package as.intellihome.neo4j.utils;

import as.intellihome.neo4j.Config;
import as.intellihome.neo4j.objects.IntelliHome;
import as.intellihome.neo4j.objects.Relations;
import org.neo4j.graphdb.GraphDatabaseService;
import org.neo4j.graphdb.Node;

// ====================================================

public class Admin
{
    private static boolean isInstalled = false;
    
    // ================================================
    
    public static synchronized void install( GraphDatabaseService graphDb )
    {
        if( !isInstalled )
        {
            IntelliHome ih = as.intellihome.neo4j.objects.IntelliHomeGeneral.getOrCreate( graphDb );
            ih.addNewStartupTime();
            
            // TODO maybe install graphDb.registerTransactionEventHandler( )
            
            isInstalled = true;
        }
        else
            throw new IllegalStateException( "already installed" );
    }
    
    // ================================================
    
    public static void shutdown( final GraphDatabaseService graphDb )
    {
        try
        { 
            if( as.intellihome.neo4j.objects.IntelliHomeGeneral.exists( graphDb ) )
            {
                IntelliHome ih = as.intellihome.neo4j.objects.IntelliHomeGeneral.getOrCreate( graphDb );
                ih.setShutdownTime();
            }
        }
        catch (Exception e) { }
        
        Thread t = new Thread()
        {
            @Override
            public void run()
            {
                //try { Thread.sleep( 1000 ); } catch (InterruptedException ie) { }
                
                graphDb.shutdown();
                
                try { Thread.sleep( as.intellihome.neo4j.Config.shutdownWaitTimeBeforeExecutionSystemExit ); } catch (InterruptedException ie) { }
                
                System.exit( 0 );
            }
        };
        
        t.setDaemon( true );
        t.start();
    }    
    
    // ================================================
    
    public static void addDefaultDataToDb( GraphDatabaseService graphDb )
    {
        if( as.intellihome.neo4j.objects.IntelliHomeGeneral.exists( graphDb ) )
        {
            IntelliHome ih = as.intellihome.neo4j.objects.IntelliHomeGeneral.getOrCreate( graphDb );
            
            as.intellihome.neo4j.objects.Relations.UserRight[] userRights = { as.intellihome.neo4j.objects.Relations.UserRight.CAN_LOGIN_TO_ADMIN };
            as.intellihome.neo4j.objects.User user = ih.createUser( Config.defaultUserNameAddedViaAddDefaultDataToDb , Config.defaultUserNameAddedViaAddDefaultDataToDb+"_pass" , Config.defaultUserNameAddedViaAddDefaultDataToDb+"_name" , Config.defaultUserNameAddedViaAddDefaultDataToDb+"_descr" , true , userRights );
            
            as.intellihome.neo4j.objects.Device device = user.createDevice( "test_device" , "This is a test device" , true , Relations.PhysicalityType.VIRTUAL , Relations.DataIncomeType.DEVICE_PUSH , Relations.InSystemLocalizationType.END_POINT , "laptop" , "Inside laptop on my desk." , 1.1d, 2.2d , 3.3d );
            
            as.intellihome.neo4j.objects.Sensor sensor = device.createSensor( "temperature" , "Temperature from Dallas DS18B20." , true , Relations.PhysicalityType.VIRTUAL ,  Relations.DataCollectingType.APPEND_UNLIMITED , Relations.DoorLocalizationType.INDOOR , Relations.SensorDataType.STRING , "computer" , "Computer under my desk." , 5.5d , 6.6d , 7.7d );
            
            sensor.createSensorSample( "val1" );
            sensor.createSensorSample( "val2" );
            sensor.createSensorSample( "val3" );
            
        }
        else
            throw new RuntimeException( "Database does not exists." );
    }
    
    // ================================================
    
    public static void deleteDb( GraphDatabaseService graphDb )
    {
        if( as.intellihome.neo4j.objects.IntelliHomeGeneral.exists( graphDb ) )
        {
            IntelliHome ih = as.intellihome.neo4j.objects.IntelliHomeGeneral.getOrCreate( graphDb );
            ih.delete(); 
        }
        else
            throw new RuntimeException( "Database does not exists." );
    }  
    
    // ================================================
    
    public static as.intellihome.neo4j.objects.User createUser( GraphDatabaseService graphDb , String login , String password , String name , String description , boolean enable , String[] userRightsAsStringArray )
    {
        as.intellihome.neo4j.objects.Relations.UserRight[] userRights = new as.intellihome.neo4j.objects.Relations.UserRight[ userRightsAsStringArray.length ];   
        for( int i = 0 ; i < userRights.length ; i++ ) userRights[ i ] = as.intellihome.neo4j.objects.Relations.UserRight.valueOf( userRightsAsStringArray[ i ] );            
            
        if( as.intellihome.neo4j.objects.IntelliHomeGeneral.exists( graphDb ) )
        {            
            IntelliHome ih = as.intellihome.neo4j.objects.IntelliHomeGeneral.getOrCreate( graphDb );
            return ih.createUser(login, password, name, description, enable, userRights);
        }
        else
            throw new RuntimeException( "Database does not exists." );
    }    
    
    // ================================================
    
    public static as.intellihome.neo4j.objects.Device createDevice( Node ownerUserNode , String name , String description , boolean enabled , String physicalityTypeAsString , String dataIncomeTypeAsString , String inSystemLocalizationTypeAsString , String locationName , String locationDescription , double locationX , double locationY , double locationZ )
    {
        as.intellihome.neo4j.objects.Relations.PhysicalityType pt = as.intellihome.neo4j.objects.Relations.PhysicalityType.valueOf( physicalityTypeAsString );
        as.intellihome.neo4j.objects.Relations.DataIncomeType dit = as.intellihome.neo4j.objects.Relations.DataIncomeType.valueOf( dataIncomeTypeAsString  );
        as.intellihome.neo4j.objects.Relations.InSystemLocalizationType islt = as.intellihome.neo4j.objects.Relations.InSystemLocalizationType.valueOf( inSystemLocalizationTypeAsString );
            
        if( as.intellihome.neo4j.objects.IntelliHomeGeneral.exists( ownerUserNode.getGraphDatabase() ) )
        {
            as.intellihome.neo4j.objects.User user = new as.intellihome.neo4j.objects.impl.User( ownerUserNode );

            as.intellihome.neo4j.objects.Device device = user.createDevice( name , description , enabled , pt , dit , islt , locationName , locationDescription , locationX , locationY , locationZ );
            
            return device;
        }
        else
            throw new RuntimeException( "Database does not exists." );
    } 
    
    // ================================================
}

// ====================================================