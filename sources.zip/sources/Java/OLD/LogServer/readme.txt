This is simple proof of concept of my REST server.

Jetty + Jersey + Jackson + Apache Derby
