This is a simple test of Neo4J ServerPlugin.
