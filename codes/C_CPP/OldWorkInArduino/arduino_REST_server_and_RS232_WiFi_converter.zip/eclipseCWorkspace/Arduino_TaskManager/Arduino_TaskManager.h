// Only modify this file to include
// - function definitions (prototypes)
// - include files
// - extern variable definitions
// In the appropriate section

#ifndef Arduino_TaskManager_H_
#define Arduino_TaskManager_H_
#include "Arduino.h"
//add your includes for the project Arduino_TaskManager here


//end of add your includes here
#ifdef __cplusplus
extern "C" {
#endif
void loop();
void setup();
#ifdef __cplusplus
} // extern "C"
#endif

//add your function definitions for the project Arduino_TaskManager here




//Do not add code below this line
#endif /* Arduino_TaskManager_H_ */
