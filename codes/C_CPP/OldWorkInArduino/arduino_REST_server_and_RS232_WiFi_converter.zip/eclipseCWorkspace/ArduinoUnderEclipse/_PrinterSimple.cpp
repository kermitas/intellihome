/*
 * PrinterSimple.cpp
 *
 *  Created on: 08-01-2012
 *      Author: root
 */

/*
#include "PrinterSimple.h"

//#include <Arduino.h>

PrinterSimple::PrinterSimple( uint8_t _horizontalLineLength )
{
	horizontalLineLength = _horizontalLineLength;
}

void PrinterSimple::printHorizontalLine()
{
	for( int i = 0 ; i < horizontalLineLength ; i++ ) Serial.print( "-" );
	Serial.println( "" );
}

void PrinterSimple::pln()
{
	Serial.println( "" );
}

PrinterSimple::~PrinterSimple()
{

}
*/
