/*
 * ePirOperationResult.cpp
 *
 *  Created on: 07-01-2012
 *      Author: root
 */

/*
#include "ePirOperationResult.h"

ePirOperationResult::ePirOperationResult( bool _isSuccessful , uint8_t _oldValue , uint8_t _newValue )
{
	isSuccessful = _isSuccessful;
	oldValue = _oldValue;
	newValue = _newValue;
}

ePirOperationResult::~ePirOperationResult()
{
}
*/
