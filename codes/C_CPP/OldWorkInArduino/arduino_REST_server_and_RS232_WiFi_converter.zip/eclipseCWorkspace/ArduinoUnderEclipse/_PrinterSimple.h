/*
 * PrinterSimple.h
 *
 *  Created on: 08-01-2012
 *      Author: root
 */

/*
#ifndef PRINTERSIMPLE_H_
#define PRINTERSIMPLE_H_

#include <Arduino.h>

class PrinterSimple
{
	public:
		PrinterSimple( uint8_t _horizontalLineLength );

		void pln();
		void printHorizontalLine();

		virtual ~PrinterSimple();

	protected:
		uint8_t horizontalLineLength;
};

#endif*/ /* PRINTERSIMPLE_H_ */
