/*
 * MemoryFree.h
 *
 *  Created on: 06-01-2012
 *      Author: root
 */

#ifndef MEMORYFREE_H_
#define MEMORYFREE_H_

	#ifdef __cplusplus
		extern "C"
		{
	#endif

			int freeRamMemory();

	#ifdef  __cplusplus
		}
	#endif

#endif /* MEMORYFREE_H_ */
