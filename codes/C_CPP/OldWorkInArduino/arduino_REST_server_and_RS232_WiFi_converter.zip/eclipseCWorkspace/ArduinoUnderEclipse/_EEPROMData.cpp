/*
 * EEPROMData.cpp
 *
 *  Created on: 09-01-2012
 *      Author: root
 */

/*
#include "EEPROMData.h"

EEPROMData::EEPROMData( unsigned int _size , uint8_t* _data , bool _freeDataOnThisClassDestruction )
{
	size = _size;
	data = _data;
	freeDataOnThisClassDestruction = _freeDataOnThisClassDestruction;
}

EEPROMData::~EEPROMData()
{
	if( freeDataOnThisClassDestruction ) delete( data );
}
*/
