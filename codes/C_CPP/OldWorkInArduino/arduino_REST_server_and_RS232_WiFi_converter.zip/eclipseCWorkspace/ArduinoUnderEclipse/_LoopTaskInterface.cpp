/*
 * LoopTaskInterface.cpp
 *
 *  Created on: 01-01-2012
 *      Author: as
 */
/*
#include "LoopTaskInterface.h"

LoopTaskInterface::LoopTaskInterface()
{

}


bool LoopTaskInterface::executeLoopTask()
{

}

LoopTaskInterface::~LoopTaskInterface()
{
	// TODO Auto-generated destructor stub
}
*/
