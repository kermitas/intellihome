/*
 * InternalEEPROMDataToWrite.h
 *
 *  Created on: 10-01-2012
 *      Author: root
 */
/*
#ifndef INTERNALEEPROMDATATOWRITE_H_
#define INTERNALEEPROMDATATOWRITE_H_

#include <Arduino.h>

class InternalEEPROMDataToWrite
{
	public:

		unsigned int dataLength;
		uint8_t* data;

		InternalEEPROMDataToWrite( unsigned int _dataLength , uint8_t* _data );
		virtual ~InternalEEPROMDataToWrite();


};

#endif*/ /* INTERNALEEPROMDATATOWRITE_H_ */
