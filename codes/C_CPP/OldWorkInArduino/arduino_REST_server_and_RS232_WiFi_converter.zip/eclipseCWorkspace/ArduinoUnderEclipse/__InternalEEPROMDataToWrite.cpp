/*
 * InternalEEPROMDataToWrite.cpp
 *
 *  Created on: 10-01-2012
 *      Author: root
 */
/*
#include "InternalEEPROMDataToWrite.h"

InternalEEPROMDataToWrite::InternalEEPROMDataToWrite( unsigned int _dataLength , uint8_t* _data )
{
	dataLength = _dataLength;
	data = _data;
}

InternalEEPROMDataToWrite::~InternalEEPROMDataToWrite()
{
}
*/
