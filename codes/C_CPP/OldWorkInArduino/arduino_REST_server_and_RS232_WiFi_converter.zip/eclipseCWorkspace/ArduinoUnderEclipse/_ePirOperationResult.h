/*
 * ePirOperationResult.h
 *
 *  Created on: 07-01-2012
 *      Author: root
 */

/*
#ifndef EPIROPERATIONRESULT_H_
#define EPIROPERATIONRESULT_H_

#include <Arduino.h>

class ePirOperationResult
{
	public:
		ePirOperationResult( bool _isSuccessful , uint8_t _oldValue , uint8_t _newValue );
		virtual ~ePirOperationResult();

		bool isSuccessful;
		uint8_t oldValue;
		uint8_t newValue;
};

#endif*/ /* EPIROPERATIONRESULT_H_ */
