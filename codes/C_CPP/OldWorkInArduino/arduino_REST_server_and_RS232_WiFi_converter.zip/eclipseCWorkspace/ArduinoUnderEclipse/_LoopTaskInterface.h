/*
 * LoopTaskInterface.h
 *
 *  Created on: 31-12-2011
 *      Author: as
 */
/*
#ifndef LoopTaskInterface_H_
#define LoopTaskInterface_H_

class LoopTaskInterface
{

	public:
		LoopTaskInterface();
		virtual bool executeLoopTask();//{};
		virtual ~LoopTaskInterface();

};

#endif /* LoopTaskInterface_H_ */

