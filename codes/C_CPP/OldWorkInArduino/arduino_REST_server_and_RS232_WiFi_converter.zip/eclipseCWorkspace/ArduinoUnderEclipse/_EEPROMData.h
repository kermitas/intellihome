/*
 * EEPROMData.h
 *
 *  Created on: 09-01-2012
 *      Author: root
 */

/*
#ifndef EEPROMDATA_H_
#define EEPROMDATA_H_

#include <Arduino.h>

class EEPROMData
{
	public:
		EEPROMData( unsigned int _size , uint8_t* _data , bool _freeDataOnThisClassDestruction );
		virtual ~EEPROMData();

		unsigned int size;
		uint8_t* data;

	protected:
		bool freeDataOnThisClassDestruction;
};

#endif *//* EEPROMDATA_H_ */

