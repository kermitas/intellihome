/*
 * DebugPrinter.cpp
 *
 *  Created on: 08-01-2012
 *      Author: root
 */

/*
#include "PrinterDebug.h"

PrinterDebug::PrinterDebug( PrinterSimple* _printerSimple , const char* _prefix )
{
	ps = _printerSimple;
	prefix = _prefix;
}

void PrinterDebug::p( const char* str )
{
	Serial.print( prefix );
	Serial.print( ":" );
	Serial.print( str );
}

void PrinterDebug::pln( const char* str )
{
	p( str );
	Serial.println( "" );
}

PrinterDebug::~PrinterDebug()
{
}

*/
