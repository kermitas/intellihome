/*
 * TaskManagerTaskInfo.cpp
 *
 *  Created on: 05-01-2012
 *      Author: root
 */

#include "TaskManagerScheduler.h"

// =================================================

/*
TaskManagerScheduler::TaskManagerScheduler() {}

// =================================================

bool TaskManagerScheduler::canExecute()
{
	return true;
}

// =================================================

bool TaskManagerScheduler::canRemoveFromTaskManager()
{
	return true;
}

// =================================================

TaskManagerScheduler::~TaskManagerScheduler() {}
*/
// =================================================
