/*
 * Runnable.cpp
 *
 *  Created on: 05-01-2012
 *      Author: root
 */

#include "Runnable.h"

Runnable::Runnable()
{
}

void Runnable::run()
{
}

Runnable::~Runnable()
{
}
