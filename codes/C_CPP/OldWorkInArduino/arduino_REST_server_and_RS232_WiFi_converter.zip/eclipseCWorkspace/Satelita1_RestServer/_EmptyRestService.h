/*
 * EmptyRestService.h
 *
 *  Created on: 12-04-2012
 *      Author: root
 */
/*
#ifndef EmptyRestService_H_
#define EmptyRestService_H_

// =================================================

#include <Arduino.h>

// =================================================

#include "RestReadOnlyService.h"

// =================================================

class EmptyRestService : public RestReadOnlyService
{
	public:

		EmptyRestService( const char* _name );
		void writeValueToStream( Stream* stream );
};

// =================================================

#endif*/ /* EmptyRestService_H_ */
