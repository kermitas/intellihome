/*
 * BasicValueSetterHTMLGenerator.h
 *
 *  Created on: 24-04-2012
 *      Author: root
 */

/*
#ifndef BASICVALUESETTERHTMLGENERATOR_H_
#define BASICVALUESETTERHTMLGENERATOR_H_

// =================================================

#include <Arduino.h>
#include <Print.h>

#include "ValueSetterHTMLGenerator.h"

// =================================================

class BasicValueSetterHTMLGenerator : public ValueSetterHTMLGenerator
{
	public:

		void generateForText( Stream* stream , const char* name );
		void generateForBoolean( Stream* stream , const char* name );
		void generateForNumber( Stream* stream , const char* name );
};

// =================================================

#endif*/ /* BASICVALUESETTERHTMLGENERATOR_H_ */
