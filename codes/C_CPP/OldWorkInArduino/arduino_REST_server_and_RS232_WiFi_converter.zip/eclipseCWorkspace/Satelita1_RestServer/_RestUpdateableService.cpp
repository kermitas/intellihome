/*
 * RestUpdateableService.cpp
 *
 *  Created on: 12-04-2012
 *      Author: root
 */
/*
// =================================================

#include "RestUpdateableService.h"

// =================================================

RestUpdateableService::RestUpdateableService( const char* _name ) : RestReadOnlyService( _name )
{

}

// =================================================

bool RestUpdateableService::isUpdateable()
{
	return true;
}
*/
// =================================================



