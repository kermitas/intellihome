/*
 * EmptyRestService.cpp
 *
 *  Created on: 12-04-2012
 *      Author: root
 */
/*
// =================================================

#include "EmptyRestService.h"

// =================================================

EmptyRestService::EmptyRestService( const char* _name ) : RestReadOnlyService( _name , 0 ) {}

// =================================================

void EmptyRestService::writeValueToStream( Stream* stream ) {}
*/
// =================================================


