/*
 * BasicValueSetterHTMLGenerator.cpp
 *
 *  Created on: 24-04-2012
 *      Author: root
 */

/*
// =================================================

#include "BasicValueSetterHTMLGenerator.h"

// =================================================

void BasicValueSetterHTMLGenerator::generateForText( Stream* stream , const char* name )
{
	stream->write( "<input type='text' name='" );
	stream->write( name );
	//stream.write( "' value='" );
	//getValue( stream );
	//stream.write( "'/>" );
	stream->write( "' />" );
}

// =================================================

void BasicValueSetterHTMLGenerator::generateForBoolean( Stream* stream , const char* name )
{
	stream->write( "<input type='text' name='" );
	stream->write( name );
	stream->write( "' />" );
}

// =================================================

void BasicValueSetterHTMLGenerator::generateForNumber( Stream* stream , const char* name )
{
	stream->write( "<input type='text' name='" );
	stream->write( name );
	stream->write( "' />" );
}
*/
// =================================================



