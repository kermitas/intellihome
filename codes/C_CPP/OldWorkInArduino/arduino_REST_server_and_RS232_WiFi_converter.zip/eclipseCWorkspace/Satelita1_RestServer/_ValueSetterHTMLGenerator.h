/*
 * ValueSetterHTMLGenerator.h
 *
 *  Created on: 24-04-2012
 *      Author: root
 */

/*
#ifndef VALUESETTERHTMLGENERATOR_H_
#define VALUESETTERHTMLGENERATOR_H_

// =================================================

#include <Arduino.h>
#include <Print.h>

// =================================================

class ValueSetterHTMLGenerator
{
	public:

		virtual void generateForText( Stream* stream , const char* name ) = 0;
		virtual void generateForBoolean( Stream* stream , const char* name ) = 0;
		virtual void generateForNumber( Stream* stream , const char* name ) = 0;
};

// =================================================

#endif*/ /* VALUESETTERHTMLGENERATOR_H_ */
