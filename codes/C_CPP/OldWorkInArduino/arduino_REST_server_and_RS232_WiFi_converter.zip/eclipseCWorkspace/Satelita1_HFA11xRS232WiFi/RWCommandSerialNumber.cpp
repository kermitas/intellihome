/*
 * RWCommandSerialNumber.cpp
 *
 *  Created on: 21-05-2012
 *      Author: root
 */

// =================================================

#include "RWCommandSerialNumber.h"

// =================================================

RWCommandSerialNumber::RWCommandSerialNumber()
{
	commandSerialNumber = 0;
}

// =================================================



