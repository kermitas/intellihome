/*
 * RWCommandSerialNumber.h
 *
 *  Created on: 21-05-2012
 *      Author: root
 */

#ifndef RWCOMMANDSERIALNUMBER_H_
#define RWCOMMANDSERIALNUMBER_H_

// =================================================

#include <Arduino.h>

// =================================================

class RWCommandSerialNumber
{
	public:

		RWCommandSerialNumber();

		byte commandSerialNumber;
};

// =================================================

#endif /* RWCOMMANDSERIALNUMBER_H_ */

