/*
 * Runnable.h
 *
 *  Created on: 05-01-2012
 *      Author: root
 */

#ifndef RUNNABLE_H_
#define RUNNABLE_H_

class Runnable
{
	public:
		//Runnable();
		virtual void run()=0;
		//virtual ~Runnable();
};

#endif /* RUNNABLE_H_ */
