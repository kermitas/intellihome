/*
 * RS232ToWiFiStreamTask.cpp
 *
 *  Created on: 21-05-2012
 *      Author: root
 */

// =================================================

#include "RS232ToWiFiStreamTask.h"

// =================================================

RS232ToWiFiStreamTask::RS232ToWiFiStreamTask() : dp( PSTR( "RS232ToWiFiTask" ) )
{
}

// =================================================

void RS232ToWiFiStreamTask::run()
{
	static const PROGMEM prog_char functionName[] = "run";
}

// =================================================


