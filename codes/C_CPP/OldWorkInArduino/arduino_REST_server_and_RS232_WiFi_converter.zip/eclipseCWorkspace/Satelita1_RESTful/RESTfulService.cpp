/*
 * RESTfulSubTask.cpp
 *
 *  Created on: 05-01-2012
 *      Author: root
 */

// =================================================

#include "RESTfulService.h"

// =================================================
/*
RESTfulService::RESTfulService()
{
}

// =================================================

const char* RESTfulService::getName()
{
	return "";
}

// =================================================

bool RESTfulService::isUpdateable()
{
	return false;
}

// =================================================

int RESTfulService::getValue()
{
	return 0;
}

// =================================================

bool RESTfulService::setValue( int newValue )
{
	return false;
}

// =================================================

int RESTfulService::getMinValue()
{
	return 0;
}

// =================================================

int RESTfulService::getMaxValue()
{
	return 0;
}

// =================================================

RESTfulService::~RESTfulService()
{
}*/

// =================================================
